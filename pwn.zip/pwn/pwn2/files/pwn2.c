#include <stdio.h>
#include <string.h>
#include <stdlib.h>  // 包含 system 函数
#define _GNU_SOURCE

void win() {
    system("/bin/sh");  // 执行 shell 命令，启动交互式 shell
}

int main() {
    char input[64];  // 增大缓冲区以容纳更长的输入

    // 禁用标准输出缓冲
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("来，写点东西: ");
    gets(input);
    printf("好，我知道你写的啥了，你个gdx!\n");
    return 0;
}

