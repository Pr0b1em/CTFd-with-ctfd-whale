#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void secret() {
    system("/bin/sh");  // 通过 system 调用获得 shell
}

int main() {
    printf("Welcome to Pr0b1em's Hackroom , enjoy yourselves!\n");
    printf("Try something!\n");
    fflush(stdout);
    secret();  // 触发漏洞
    return 0;
}

