# CISCN 2019 华北赛区 Day1 Web1

## 题目详情

- **2019 CISCN 2019 华北赛区 Day1 Web1**

## 考点

- 代码审计
- PHP 反序列化（Phar）

## 启动

    docker-compose up -d
    open http://127.0.0.1:8302/

## 版权

该题目复现环境尚未取得主办方及出题人相关授权，如果侵权，请联系本人删除（ i@zhaoj.in ）
