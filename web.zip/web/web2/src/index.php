<?php
// 数据库配置
$servername = "localhost";
$username = "root"; // 替换为你的数据库用户名
$password = "root"; // 替换为你的数据库密码
$dbname = "test_db"; // 替换为你的数据库名

// 连接数据库
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接是否成功
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 检查是否有查询提交
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["query"])) {
    $query = $_POST["query"];

    // 执行查询
    if ($result = $conn->query($query)) {
        echo "<div class='result'><h3>查询结果:</h3><table border='1' cellpadding='5'>";
        echo "<tr>";

        // 获取字段名
        while ($field_info = $result->fetch_field()) {
            echo "<th>{$field_info->name}</th>";
        }
        echo "</tr>";

        // 获取每行数据
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $data) {
                echo "<td>{$data}</td>";
            }
            echo "</tr>";
        }
        echo "</table></div>";
        $result->free();
    } else {
        echo "<p>查询失败: " . $conn->error . "</p>";
    }
}

$conn->close();
?>

