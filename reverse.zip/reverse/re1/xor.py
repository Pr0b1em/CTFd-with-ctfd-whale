# 提供的加密后的字符（ASCII 值）
encrypted_values = [122, 88, 26, 72, 27, 79, 71, 81, 120, 25, 92, 25, 88, 89, 25, 117, 27, 31, 117, 82, 26, 88, 117, 26, 88, 117, 68, 26, 29, 21, 87]

# 解密过程：对每个加密的字符与 42 进行异或操作
decrypted_flag = ''.join(chr(value ^ 43) for value in encrypted_values)

# 输出解密后的 flag
print("Decrypted flag:", decrypted_flag)

