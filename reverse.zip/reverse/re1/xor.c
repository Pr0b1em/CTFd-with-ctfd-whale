#include <stdio.h>
#include <string.h>

int main() {
    // 原始 flag
    char flag[] = "Pr0b1em{R3v3rs3_15_x0r_0r_n07?}";
    int flag_length = strlen(flag);

    // 加密后的数组
    int encrypted_flag[100];

    // 加密过程：每个字符与 42 进行异或操作
    for (int i = 0; i < flag_length; i++) {
        encrypted_flag[i] = flag[i] ^ 42; // 使用 42 作为异或值
        printf("%d ", encrypted_flag[i]);  // 输出加密后的字符的 ASCII 值
    }

    return 0;
}

