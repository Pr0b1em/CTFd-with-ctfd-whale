#include <stdio.h>
#include <string.h>

// 检查输入的 flag 是否正确
int check_flag(const char* input) {
    // 替换为您上面提供的加密后的 flag
    char encrypted_flag[] = {122, 88, 26, 72, 27, 79, 71, 81, 120, 25, 92, 25, 88, 89, 25, 117,
                             27, 31, 117, 82, 26, 88, 117, 26, 88, 117, 68, 26, 29, 21, 87};
    int length = sizeof(encrypted_flag) / sizeof(encrypted_flag[0]);

    // 检查输入的长度是否与加密后的 flag 长度一致
    if (strlen(input) != length) {
        return 0; // 长度不匹配
    }

    // 校验输入的每个字符，进行异或操作后与加密后的字符对比
    for (int i = 0; i < length; i++) {
        if ((input[i] ^ 42) != encrypted_flag[i]) { // 异或 42 得到正确字符
            return 0; // 如果任何字符不匹配，则返回 0
        }
    }

    return 1; // 所有字符匹配，返回 1
}

int main() {
    char input[100]; // 用户输入的 flag

    // 提示用户输入 flag
    printf("Enter the flag: ");
    scanf("%99s", input); // 读取用户输入

    // 校验输入的 flag
    if (check_flag(input)) {
        printf("Correct! The flag is: %s\n", input); // 如果正确，输出 flag
    } else {
        printf("Wrong flag!\n"); // 如果错误，输出错误信息
    }

    return 0;
}

